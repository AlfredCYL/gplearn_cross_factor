
__version__ = '1.0.1'

__all__ = ['genetic', 'fitness', 'functions', 'more_functions']
